﻿Trimmer(AGeNT 3.1)
===============
AGeNT Trimmer removes adaptor sequences from sequencing reads. And for sequencing reads using library preparation kits with the Molecular Barcode(MBC), Trimmer also processes the MBC and adds the MBC information to the read name in the output FASTQ files. Downstream tools, such as AGeNT CReaK make use of these MBC tags in identifying PCR duplicates.

For dual-MBC data (e.g. SureSelect XT HS2) Trimmer removes the 5' end MBC and the inline MBC from sequencing reads and adds them to the line of the read name under SAM tags RX:Z and QX:Z.
For single-MBC data (e.g. SureSelect XT HS) Trimmer also annotates sequencing reads with the MBC if the MBC index file is provided with right option.

*Note: This jar was compiled using Java version 11. Please make sure your Java Runtime Environment is at least at version 11 by running the command* `java -version`.

**Command-line syntax:**
To test that you can run Trimmer, run the following command:
```
java -jar /path/to/trimmer-<version>.jar
```
or, if you have setup an environment variable (such as \$TRIMMER) as a shortcut:
```
java -jar $TRIMMER
```
You should see the Trimmer help text.

Example command-line:
```
java -jar trimmer-<version>.jar [mandatory options] [options] -fq1 <read1_filename> -fq2 <read2_filename>
```

**Required parameters:**

Parameter              | Description                        
---------              | -----------                         
`-fq1 <filename>`      | Read1 FASTQ file (Multiple files can be provided separated by a comma).
`-fq2 <filename>`      | Read2 FASTQ file (Multiple files can be provided separated by a comma).
`-adaptor <IlluminaXT,IlluminaQXT,MGI>`  | Sequencing adaptor used for input data (default is IlluminaXT). For sequencing adaptor that is neither Illumina nor MGI, see `-customAdaptor` in Optional Parameters. 
`-mbc <null,xths2>`  | The dual MBC used for input data. 'null' means no dual MBC is used, 'xths2' means the SureSelect XT HS2 MBC is used. For the dual MBC that is not XT HS2, see `-mbc <PATTERN>` in Optional Parameters.

***Note:***  *Even though -fq1 and -fq2 accept multiple files separated by a comma, the program will output results in a single file for each read.*

Below are options marked deprecated in this version and their replacements should be used accordingly.

Deprecated Option| Library Prep Type | replacement        
------| ---------------------------- |------------
`-halo` | HaloPlex | N/A
`-hs`   | HaloPlexHS | N/A
`-xt`   | SureSelect XT, XT2, XT HS | `-adaptor IlluminaXT -mbc null`
`-v2`   | SureSelect XT HS2 | `-adaptor IlluminaXT -mbc xths2`
`-qxt`  | SureSelect QXT | `-adaptor IlluminaQXT -mbc null`


**Optional Parameters:**

| Option | Description |
| ----------|-------------|
| `-fq3 <filename>` | This option is only relevant for SureSelect XT HS. MBCs FASTQ file (Multiple files can be provided separated by a comma).| 
| `-bam` | Turn on to output unaligned bam file instead of fastq files |
| `-out` | Alternative output file name (file path + file name prefix) |
| `-polyG <n>` | The minimum length of polyG to trim from 3' end regardless of base quality (for nextSeq and NovaSeq polyG problem). <br> Value range is >= 1. |
| `-qualityTrimming <n>` |  Quality threshold for trimming. <br> Value range is 0 to 50. Default is 5. |
| `-customAdaptor <read 1 adaptor,read 2 adaptor>`| The adaptor sequences have to be in A/C/T/G, and from 5' to 3'. Read 1 adaptor and read 2 adaptor should be concatenated with comma, and with read 1 adaptor being the first. <br>For example: -customAdaptor CCCCGAAAAAGC,GGGGCCCCA |
| `-mbc <PATTERN>`| How to specify the PATTERN: use `N` to represent MBC base and `D` to represent dark base. If the dark base is not a wild card base, then specify the fixed base with `A/T/C/G`. If there are multiple patterns the MBC may follow, seperate them with comma. <br>For example: XT HS2 MBC has 3 MBC bases and 1 or 2 dark bases that must be T or (C/G)T, so the PATTERN should be `NNNT,NNNCT,NNNGT` |
| `-minFractionRead <n>`   | The minimum read length as a fraction of the original read length after trimming.<br>Value range is 0 to 99. Default is 30. |
| `-idee_fixe` | For the fastq files that are in the older Illumina fastq format (v1.5 or earlier) that has `/1` and `/2` in the read name to indicate read 1 and read 2. `/1` and `/2` will be removed in the output files. |
| `-qual_offset <n>`| Overwrite auto-detection to indicate FASTQ quality encoding (1 for Phred+33, 2 for Phred+64, 3 for Solexa+64) |
| `-out_loc` | Directory path for output files.  |
| `-minMateOverlap <n>` | The minimum mate overlap to search for adaptor. <br>Value range is > 0. Default is 50. |
| `-bgzf` | Block compression on top of GZIP for output FASTQ file (.bgz as file extension).  |
| `-compressionLevel <n>` | GZIP compression level. <br> Value range is 1 to 9. Default is 6. |


**Usage Examples:**<br>

*  SureSelect XT HS2 example

```
java -jar trimmer-<version>.jar \
     -fq1 ./ICCG-repl1_S1_L001_R1_001.fastq.gz,./ICCG-repl1_S1_L001_R1_002.fastq.gz \
     -fq2 ./ICCG-repl1_S1_L001_R2_001.fastq.gz,./ICCG-repl1_S1_L001_R2_002.fastq.gz \ 
     -adaptor IlluminaXT -mbc xths2  \
     -out myOutputDirPath/myOutputFilePrefix
```

*  SureSelect XT HS example (with MBC tagging)

```
java -jar trimmer-<version>.jar \
     -fq1 ./ICCG-repl1_S1_L001_R1_001.fastq.gz,./ICCG-repl1_S1_L001_R1_002.fastq.gz \
     -fq2 ./ICCG-repl1_S1_L001_R2_001.fastq.gz,./ICCG-repl1_S1_L001_R2_002.fastq.gz \
     -fq3 ./ICCG-repl1_S1_L001_I2_001.fastq.gz,./ICCG-repl1_S1_L001_I2_002.fastq.gz \     
     -adaptor IlluminaXT -mbc null  \
     -out myOutputDirPath/myOutputFilePrefix
```

*  SureSelect XT HS example (without MBC tagging)

```
java -jar trimmer-<version>.jar \
     -fq1 ./ICCG-repl1_S1_L001_R1_001.fastq.gz,./ICCG-repl1_S1_L001_R1_002.fastq.gz \
     -fq2 ./ICCG-repl1_S1_L001_R2_001.fastq.gz,./ICCG-repl1_S1_L001_R2_002.fastq.gz \
     -adaptor IlluminaXT -mbc null  \
     -out myOutputDirPath/myOutputFilePrefix
```

*  Halo example

```
java -jar trimmer-<version>.jar \
     -fq1 ./ICCG-repl1_S1_L001_R1_001.fastq.gz,./ICCG-repl1_S1_L001_R1_002.fastq.gz \
     -fq2 ./ICCG-repl1_S1_L001_R2_001.fastq.gz,./ICCG-repl1_S1_L001_R2_002.fastq.gz \
     -halo  \
     -out_loc result/outputFastqs/
```

*  MGI example (Illumina adaptor, with XT HS2 MBC)

```
java -jar trimmer-<version>.jar \
     -fq1 ./ICCG-repl1_S1_L001_R1_001.fastq.gz,./ICCG-repl1_S1_L001_R1_002.fastq.gz \
     -fq2 ./ICCG-repl1_S1_L001_R2_001.fastq.gz,./ICCG-repl1_S1_L001_R2_002.fastq.gz \
     -adaptor IlluminaXT -mbc xths2 \
     -out_loc result/outputFastqs/
```

*  MGI example (MGI adaptor, with XT HS2 MBC)

```
java -jar trimmer-<version>.jar \
     -fq1 ./ICCG-repl1_S1_L001_R1_001.fastq.gz,./ICCG-repl1_S1_L001_R1_002.fastq.gz \
     -fq2 ./ICCG-repl1_S1_L001_R2_001.fastq.gz,./ICCG-repl1_S1_L001_R2_002.fastq.gz \
     -adaptor MGI -mbc xths2 \
     -out_loc result/outputFastqs/
```
*  MGI example (MGI adaptor, without dual MBC)

```
java -jar trimmer-<version>.jar \
     -fq1 ./ICCG-repl1_S1_L001_R1_001.fastq.gz,./ICCG-repl1_S1_L001_R1_002.fastq.gz \
     -fq2 ./ICCG-repl1_S1_L001_R2_001.fastq.gz,./ICCG-repl1_S1_L001_R2_002.fastq.gz \
     -adaptor MGI -mbc null \
     -out_loc result/outputFastqs/
```
*  Non-XTHS2/Custom dual MBC example 1 (MGI adaptor, with 7-base MBC that has 5 UMI bases and 2 dark bases  )

```
java -jar trimmer-<version>.jar \
     -fq1 ./ICCG-repl1_S1_L001_R1_001.fastq.gz,./ICCG-repl1_S1_L001_R1_002.fastq.gz \
     -fq2 ./ICCG-repl1_S1_L001_R2_001.fastq.gz,./ICCG-repl1_S1_L001_R2_002.fastq.gz \
     -adaptor mgi -mbc NNNNNDD \
     -out_loc result/outputFastqs/
```

*  Non-XTHS2/Custom dual MBC example 2 (Illumina adaptor, with 5-base MBC that has 3 UMI bases and 2 fixed dark bases that is CT  )

```
java -jar trimmer-<version>.jar \
     -fq1 ./ICCG-repl1_S1_L001_R1_001.fastq.gz,./ICCG-repl1_S1_L001_R1_002.fastq.gz \
     -fq2 ./ICCG-repl1_S1_L001_R2_001.fastq.gz,./ICCG-repl1_S1_L001_R2_002.fastq.gz \
     -adaptor IlluminaXT -mbc NNNCT \
     -out_loc result/outputFastqs/
```
***Note:***  *MGI FASTQ file could be in BGI or HiSeq format. If in BGI format, apply the option -IDEE_FIXE to deal with the /1 and /2 in read name.*


**Tags for SureSelect XT HS and SureSelect XT HS2:**

For the SureSelect XT HS and XT HS2 options, trimmed molecular barcodes (MBCs) are formatted as valid SAM tags and added to the read name line. These annotation tags are:

* BC:Z:*sample barcode*
* ZA:Z:*3 bases of MBC (first half of dual MBC) followed by 1 or 2 dark base(s)*
* ZB:Z:*3 bases of MBC (second half of dual MBC) followed by 1 or 2 dark base(s)*
* RX:Z:*first half of MBC + second half of MBC concatenated with a "-")*
* QX:Z:*base quality of sequence in RX:Z (concatenated with a space)* 

e.g.
`@D00266:1113:HTWK5BCX2:1:1102:9976:2206 BC:Z:CTACCGAA+AAGTGTCT ZA:Z:TTAGT ZB:Z:TCCT RX:Z:TTA-TCC QX:Z:DDD DDA`

***Note:*** *The MBC bases are masked as* **N** *and corresponding base qualities marked as* **$** *in some annotations if they are not recognized as a valid XT HS2 MBC.*

e.g.
`@K00336:80:HW7GLBBXX:7:1115:1184:3688 BC:Z:CTACCGAA+AGACACTT ZA:Z:NNNNN ZB:Z:AAAGT RX:Z:NNN-AAA QX:Z:$$$ <AA`

<br>

**Output for SureSelect XT HS2:**

For dual-MBC data such as SureSelect XT HS2, for every two FASTQ files (read 1 FASTQ file and read 2 FASTQ file) the program outputs three compressed files when not in BAM mode (-bam option): 
* trimmed read 1 FASTQ file (.fastq.gz)
* trimmed read 2 FASTQ file (.fastq.gz)
* MBC sequence file (.txt.gz).